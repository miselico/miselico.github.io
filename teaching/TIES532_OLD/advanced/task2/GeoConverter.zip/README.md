GeoConverter
=============

This library can be used to convert between 
	* WGS84 
		* expressed in latitude and longitude, 
		* used for instance by google maps
	* KKJ 
		* expressed in x,y = I,P = Easting, Northing
		* used in Finland before 2005 (but still around)

When KKJ3 is needed, use KKJ with KKJ_ZONE_INFO set to KKJ_ZONE_INFO.ZONE3.


This library was inspired by parts of code from http://zil.olammi.iki.fi/sw/fetch_map/
More information about the Finnish coordinate systems http://www.kolumbus.fi/eino.uikkanen/geodocsgb/ficoords.htm
