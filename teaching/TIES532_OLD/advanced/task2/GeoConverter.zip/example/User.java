import advancedTask.geoConverter.Converter;
import advancedTask.geoConverter.KKJ_ZONE_INFO;
import advancedTask.geoConverter.KKJxy;
import advancedTask.geoConverter.WGS84lalo;


public class User {
	public static void main(String[] args) {
		//Tikkurila station is located at 60.29208724493154, 25.04380510751087 in WGS84lalo
		KKJxy tikkurilaKKJ3 = Converter.WGS84lalo_to_KKJxy(new WGS84lalo(60.29208724493154, 25.04380510751087), KKJ_ZONE_INFO.ZONE3);
		System.out.println(tikkurilaKKJ3);
		
		//Tikkurila station is located at  3391988.0   6688352.0 in KKJ3 xy
		WGS84lalo tikkurilaWSG84 = Converter.KKJxy_to_WGS84lalo(tikkurilaKKJ3, KKJ_ZONE_INFO.ZONE3);
		System.out.println(tikkurilaWSG84);
	}
}
